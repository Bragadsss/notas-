function verificarAprovacao(nota, faltas) {

    if (nota >= 7 & faltas <= 20) {
        return "Aluno aprovado";
    } else {
        return "Aluno reprovado";
    }
}


console.log(verificarAprovacao(8.5, 15));  
console.log(verificarAprovacao(6.0, 18));  
console.log(verificarAprovacao(7.0, 21));  
console.log(verificarAprovacao(7.5, 20));  
